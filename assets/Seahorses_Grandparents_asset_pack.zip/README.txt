SEAHORSES GRANDPARENTS — IMAGE ASSET PACK
==========================================

Internal working label only. Do not display the product name on the website yet.

Folders:
- presentation/: color, monochrome, and original artwork presentation images.
- details/color/: five cropped color detail references.
- details/black-white/: grayscale variants and alternate monochrome detail references.
- tattoo-mockups/: separate reference crops showing the design on skin.
- artwork/: original uploaded reference and grayscale version.

Important production note:
These files are prepared as separated visual assets from the supplied reference and generated portfolio sheet.
The tattoo mockups are presentation references, not clean tattoo flash.
The close-up crops are detail/reference images, not independent full-resolution original designs.
No claim is made that any file has a true transparent background. The dark background and black design elements overlap, so automatic background removal can destroy parts of the artwork.
Before selling as tattooer downloads, prepare and inspect a clean isolated master design with true alpha transparency, then export the available print sizes/resolutions and licensed customer/tattooer packages.
No text or product title has been added to the images.
