ART TO INK — website prototype

Open index.html locally or import this folder into a static-hosting project.

Included:
- English-language luxury storefront and conversion-focused landing page
- Eight artwork/archive cards with colour and black-and-grey viewing direction
- Personal-use vs professional artist-licensing funnel
- Currency display toggle (illustrative conversions only)
- Cart interaction demo
- Customer tattoo submission form with local preview only
- Newsletter signup demo

IMPORTANT LAUNCH REQUIREMENTS:
This is a frontend prototype, not a live store. No payments, digital file delivery, customer upload service, email capture, real currency settlement, or tax handling is connected. Product prices are illustrative. Artwork shown in the gallery is cropped from Instagram screenshots supplied by the artist and should be replaced with clean, high-resolution source files. Black-and-grey presentation uses visual filtering in the preview; it is not a separate downloadable tattoo-ready file. Final stencil artwork, licensing terms, privacy/consent process, refund policy, tax configuration and payment integration must be completed before selling.
